import image1 from '../imgs/1960-Aguascaliente1.png';
import image2 from '../imgs/1960-Aguascaliente2.png';
import image3 from '../imgs/1960-Aguascaliente3.png';
//const pdfImages = ['../imgs/1960-Aguascaliente1.png', '../imgs/1960-Aguascaliente2.png', '../imgs/1960-Aguascaliente3.png']
const images = [image1, image2, image3];
export default images;