## API_2

API_2 is the test API for interfacing with the AWS backend, unlike API_1, which is testing only, API_2 is the first API to be used in production.\
Please see `docs\AWS\API_2.md` for more information