import React from 'react';
import ResetPassword from '../components/ResetPassword';

const PasswordReset = () => {
    return (
        <div className="App-header">
            <ResetPassword/>
        </div>
    )
}

export default PasswordReset;