
import React from 'react'

const Files = () => {

    return (
        <div>
            <h1>Settings</h1>
        </div>
    )
}

export default Files